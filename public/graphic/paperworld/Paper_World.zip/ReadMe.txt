How to play:
The game is a .exe file, so you only need to open it (No installation needed).
It will only work on Windows